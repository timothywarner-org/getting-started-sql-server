-- sqlcmd example: run a quick query
SELECT TOP (5) CustomerID, CustomerName FROM Sales.Customers ORDER BY CustomerID;
