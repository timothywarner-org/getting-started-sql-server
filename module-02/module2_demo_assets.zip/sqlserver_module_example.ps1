# PowerShell example using SqlServer module
Import-Module SqlServer
Invoke-Sqlcmd -ServerInstance 'localhost' -Database 'WideWorldImporters' -Query 'SELECT COUNT(*) FROM Sales.Customers;'
