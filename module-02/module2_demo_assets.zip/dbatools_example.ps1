# PowerShell example using dbatools
Import-Module dbatools
Get-DbaDatabase -SqlInstance 'localhost' | Select-Object Name, SizeMB
